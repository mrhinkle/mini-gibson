ARCHIVED OVERLAY — public-safe packaging, 2026-10-16.
All 11 implementation files below are already integrated by PR #15. Do not
apply this overlay over current main. Use docs/readiness/README.md for current
instructions. The original dated instructions below are preserved as history.
Only private host paths and corpus fingerprints were removed from this README;
all source files and FILES.sha256.json retain their original bytes.

MINI GIBSON READINESS CODE SNAPSHOT — 2026-10-15 EDT

This overlay has 11 new repository files. Apply only to a clean checkout of:
2da3221e210a53d3365f5f4c2314992f6e9e404a (benchmark PR #14, open when checked).
It includes the SFT foundation merged in PR #13. No commit or push was made.

The companion mini-gibson-readiness.patch contains these exact additions.
Check it first with git apply --check, then apply it only in your chosen checkout.
The ZIP is the same 11-file source overlay plus this README and FILES.sha256.json.
It is not a standalone checkout. Original repository files and pinned external
NVIDIA libraries remain required.

Codex authored the exporter, adapter and synthetic provider smoke. Grok authored
the inference checker. Claude independently approved the combined bundle after
prior component reviews; Codex also reviewed the Grok checker. The integrated
historical/runtime/evaluation suite passed 129 tests and 170 subtests. Local checks
are distinct from CI; no CI run or remote release is claimed.

The ZIP contains no training records, token arrays, private session logs, model
weights, credentials or virtual environment. The selected private data candidate remains outside Git. Its host path and
corpus fingerprints are omitted from this public archive.

The first prepared-v8 directory is a superseded diagnostic; do not train from it.
Use docs/readiness-data-preparation.md for exact preparation semantics and pins.
Existing output destinations are refused, so use a fresh destination for retries.
Read the companion readiness report and rehearsal command sheet before runtime
work. GPU commands are PREPARED ONLY: wait to launch. Corpus stays private.

CPU rendering, mask and batch-format evidence passed. Actual NeMo/Torch loader,
optimizer/checkpoint/export/serving, runtime tool conformance, full training and
release are NOT approved by these artifacts. The actual loader is NOT_RUN.
Design issue #417 and organizer eligibility clarification remain open.
